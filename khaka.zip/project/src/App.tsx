import React, { useRef, useState, useEffect } from 'react';
import { Upload, Image as ImageIcon, Download, Grid, Maximize } from 'lucide-react';

function App() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [threshold, setThreshold] = useState<number>(30);
  const [originalImageData, setOriginalImageData] = useState<ImageData | null>(null);
  const [aspectRatio, setAspectRatio] = useState<{ width: number; height: number }>({ width: 1, height: 1 });
  const [pieces, setPieces] = useState<{ width: number; height: number }>({ width: 1, height: 1 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pieceCanvasRef = useRef<HTMLCanvasElement>(null);

  // A4 dimensions in pixels at 300 DPI
  const A4_WIDTH = 2480;
  const A4_HEIGHT = 3508;

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          setOriginalImage(img.src);
          processImage(img);
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const gaussianBlur = (data: Uint8ClampedArray, width: number, height: number, radius: number = 2): Uint8ClampedArray => {
    const kernel = generateGaussianKernel(radius);
    const result = new Uint8ClampedArray(data.length);
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        let r = 0, g = 0, b = 0;
        let weightSum = 0;
        
        for (let ky = -radius; ky <= radius; ky++) {
          for (let kx = -radius; kx <= radius; kx++) {
            const px = x + kx;
            const py = y + ky;
            if (px >= 0 && px < width && py >= 0 && py < height) {
              const weight = kernel[ky + radius][kx + radius];
              const idx = (py * width + px) * 4;
              r += data[idx] * weight;
              g += data[idx + 1] * weight;
              b += data[idx + 2] * weight;
              weightSum += weight;
            }
          }
        }
        
        const idx = (y * width + x) * 4;
        result[idx] = r / weightSum;
        result[idx + 1] = g / weightSum;
        result[idx + 2] = b / weightSum;
        result[idx + 3] = data[idx + 3];
      }
    }
    
    return result;
  };

  const generateGaussianKernel = (radius: number): number[][] => {
    const size = 2 * radius + 1;
    const kernel: number[][] = Array(size).fill(0).map(() => Array(size).fill(0));
    const sigma = radius / 2;
    let sum = 0;
    
    for (let y = -radius; y <= radius; y++) {
      for (let x = -radius; x <= radius; x++) {
        const exponent = -(x * x + y * y) / (2 * sigma * sigma);
        const value = Math.exp(exponent) / (2 * Math.PI * sigma * sigma);
        kernel[y + radius][x + radius] = value;
        sum += value;
      }
    }
    
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        kernel[y][x] /= sum;
      }
    }
    
    return kernel;
  };

  const sobelEdgeDetection = (data: Uint8ClampedArray, width: number, height: number, threshold: number): Uint8ClampedArray => {
    const result = new Uint8ClampedArray(data.length);
    const sobelX = [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]];
    const sobelY = [[-1, -2, -1], [0, 0, 0], [1, 2, 1]];
    
    let maxMagnitude = 0;
    const magnitudes: number[] = [];
    
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let pixelX = 0;
        let pixelY = 0;
        
        for (let i = -1; i <= 1; i++) {
          for (let j = -1; j <= 1; j++) {
            const idx = ((y + i) * width + (x + j)) * 4;
            const gray = data[idx];
            pixelX += gray * sobelX[i + 1][j + 1];
            pixelY += gray * sobelY[i + 1][j + 1];
          }
        }
        
        const magnitude = Math.sqrt(pixelX * pixelX + pixelY * pixelY);
        maxMagnitude = Math.max(maxMagnitude, magnitude);
        magnitudes.push(magnitude);
      }
    }
    
    const normalizedThreshold = (maxMagnitude * threshold) / 100;
    let magnitudeIndex = 0;
    
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const magnitude = magnitudes[magnitudeIndex++];
        const edgeValue = magnitude > normalizedThreshold ? 255 : 0;
        
        result[idx] = edgeValue;
        result[idx + 1] = edgeValue;
        result[idx + 2] = edgeValue;
        result[idx + 3] = 255;
      }
    }
    
    return result;
  };

  const processImage = (img: HTMLImageElement) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Calculate new dimensions based on aspect ratio
    const targetWidth = img.width * aspectRatio.width;
    const targetHeight = img.height * aspectRatio.height;

    // Set canvas size
    canvas.width = targetWidth;
    canvas.height = targetHeight;

    // Draw and scale image
    ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

    // Get image data
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;

    // Store original image data for reprocessing
    setOriginalImageData(imageData);

    // Process the image with current threshold
    processImageData(imageData);
  };

  const processImageData = (imageData: ImageData) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const data = new Uint8ClampedArray(imageData.data);

    // Convert to grayscale
    for (let i = 0; i < data.length; i += 4) {
      const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
      data[i] = avg;
      data[i + 1] = avg;
      data[i + 2] = avg;
    }

    // Apply Gaussian blur
    const blurredData = gaussianBlur(data, canvas.width, canvas.height, 2);
    
    // Apply Sobel edge detection with current threshold
    const edgeData = sobelEdgeDetection(blurredData, canvas.width, canvas.height, threshold);
    
    // Create new ImageData and put it back on canvas
    const processedImageData = new ImageData(edgeData, canvas.width, canvas.height);
    ctx.putImageData(processedImageData, 0, 0);
    
    setProcessedImage(canvas.toDataURL());
  };

  // Generate individual puzzle pieces
  const generatePuzzlePieces = () => {
    if (!processedImage) return [];

    const img = new Image();
    img.src = processedImage;

    const pieceWidth = img.width / pieces.width;
    const pieceHeight = img.height / pieces.height;
    const puzzlePieces: string[] = [];

    const tempCanvas = document.createElement('canvas');
    const tempCtx = tempCanvas.getContext('2d');
    if (!tempCtx) return [];

    // Set canvas size to A4 dimensions
    tempCanvas.width = A4_WIDTH;
    tempCanvas.height = A4_HEIGHT;

    for (let row = 0; row < pieces.height; row++) {
      for (let col = 0; col < pieces.width; col++) {
        // Clear canvas
        tempCtx.fillStyle = 'white';
        tempCtx.fillRect(0, 0, A4_WIDTH, A4_HEIGHT);

        // Calculate source and destination dimensions
        const sx = col * pieceWidth;
        const sy = row * pieceHeight;
        const margin = 100; // Margin in pixels
        const availableWidth = A4_WIDTH - (margin * 2);
        const availableHeight = A4_HEIGHT - (margin * 2);
        
        // Scale piece to fit A4 while maintaining aspect ratio
        const scale = Math.min(
          availableWidth / pieceWidth,
          availableHeight / pieceHeight
        );
        
        const scaledWidth = pieceWidth * scale;
        const scaledHeight = pieceHeight * scale;
        
        // Center the piece on the A4 page
        const dx = (A4_WIDTH - scaledWidth) / 2;
        const dy = (A4_HEIGHT - scaledHeight) / 2;

        // Draw the piece
        tempCtx.drawImage(
          img,
          sx, sy, pieceWidth, pieceHeight,
          dx, dy, scaledWidth, scaledHeight
        );

        // Add piece number
        tempCtx.font = '48px Arial';
        tempCtx.fillStyle = 'black';
        tempCtx.fillText(`Piece ${row * pieces.width + col + 1}`, margin, margin);

        // Add cutting guides
        tempCtx.strokeStyle = '#ccc';
        tempCtx.setLineDash([5, 5]);
        tempCtx.strokeRect(dx, dy, scaledWidth, scaledHeight);

        puzzlePieces.push(tempCanvas.toDataURL());
      }
    }

    return puzzlePieces;
  };

  const downloadPuzzlePieces = () => {
    const puzzlePieces = generatePuzzlePieces();
    puzzlePieces.forEach((piece, index) => {
      const link = document.createElement('a');
      link.download = `puzzle-piece-${index + 1}.png`;
      link.href = piece;
      link.click();
    });
  };

  // Reprocess image when parameters change
  useEffect(() => {
    if (originalImageData) {
      processImageData(originalImageData);
    }
  }, [threshold, aspectRatio]);

  return (
    <div className="min-h-screen embroidery-pattern">
      <div className="max-w-5xl mx-auto p-8">
        <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-2xl p-8 mb-8 border border-amber-800/10">
          <div className="text-center mb-12">
            <h1 className="font-['Cormorant_Garamond'] text-4xl font-bold text-amber-900 mb-2">
              Artistic Image Transformation
            </h1>
            <p className="font-['Montserrat'] text-amber-800/70 text-sm">
              Transform your images into elegant line art pieces
            </p>
          </div>
          
          {/* Upload Section */}
          <div className="mb-12">
            <label 
              htmlFor="image-upload"
              className="flex items-center justify-center w-full h-40 px-4 transition bg-amber-50/50 border-2 border-amber-800/20 border-dashed rounded-lg appearance-none cursor-pointer hover:border-amber-800/40 focus:outline-none group"
            >
              <div className="flex flex-col items-center space-y-3">
                <Upload className="w-10 h-10 text-amber-800/40 group-hover:text-amber-800/60 transition-colors" />
                <span className="font-['Montserrat'] text-sm text-amber-800/60">
                  Upload your image to begin the transformation
                </span>
              </div>
              <input
                id="image-upload"
                type="file"
                className="hidden"
                accept="image/*"
                onChange={handleImageUpload}
              />
            </label>
          </div>

          {originalImage && (
            <div className="space-y-8">
              {/* Edge Detection Controls */}
              <div className="bg-amber-50/30 p-6 rounded-lg border border-amber-800/10">
                <label htmlFor="threshold" className="block font-['Montserrat'] text-sm font-medium text-amber-900 mb-3">
                  Artistic Detail Level: {threshold}%
                </label>
                <input
                  type="range"
                  id="threshold"
                  min="0"
                  max="100"
                  value={threshold}
                  onChange={(e) => setThreshold(Number(e.target.value))}
                  className="w-full h-2 bg-amber-200/50 rounded-lg appearance-none cursor-pointer accent-amber-800"
                />
              </div>

              {/* Aspect Ratio Controls */}
              <div className="bg-amber-50/30 p-6 rounded-lg border border-amber-800/10">
                <h3 className="font-['Montserrat'] text-sm font-medium text-amber-900 mb-3 flex items-center gap-2">
                  <Maximize className="w-4 h-4" />
                  Canvas Proportions
                </h3>
                <div className="flex gap-6">
                  <div>
                    <label className="block font-['Montserrat'] text-sm text-amber-800/70">Width</label>
                    <input
                      type="number"
                      min="1"
                      value={aspectRatio.width}
                      onChange={(e) => setAspectRatio(prev => ({ ...prev, width: Number(e.target.value) }))}
                      className="w-24 px-3 py-2 border rounded-md input-style font-['Montserrat']"
                    />
                  </div>
                  <div>
                    <label className="block font-['Montserrat'] text-sm text-amber-800/70">Height</label>
                    <input
                      type="number"
                      min="1"
                      value={aspectRatio.height}
                      onChange={(e) => setAspectRatio(prev => ({ ...prev, height: Number(e.target.value) }))}
                      className="w-24 px-3 py-2 border rounded-md input-style font-['Montserrat']"
                    />
                  </div>
                </div>
              </div>

              {/* Puzzle Pieces Controls */}
              <div className="bg-amber-50/30 p-6 rounded-lg border border-amber-800/10">
                <h3 className="font-['Montserrat'] text-sm font-medium text-amber-900 mb-3 flex items-center gap-2">
                  <Grid className="w-4 h-4" />
                  Pattern Division
                </h3>
                <div className="flex gap-6">
                  <div>
                    <label className="block font-['Montserrat'] text-sm text-amber-800/70">Columns</label>
                    <input
                      type="number"
                      min="1"
                      value={pieces.width}
                      onChange={(e) => setPieces(prev => ({ ...prev, width: Number(e.target.value) }))}
                      className="w-24 px-3 py-2 border rounded-md input-style font-['Montserrat']"
                    />
                  </div>
                  <div>
                    <label className="block font-['Montserrat'] text-sm text-amber-800/70">Rows</label>
                    <input
                      type="number"
                      min="1"
                      value={pieces.height}
                      onChange={(e) => setPieces(prev => ({ ...prev, height: Number(e.target.value) }))}
                      className="w-24 px-3 py-2 border rounded-md input-style font-['Montserrat']"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Image Display */}
          {originalImage && processedImage && (
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <h2 className="font-['Cormorant_Garamond'] text-xl font-semibold text-amber-900 flex items-center gap-2">
                  <ImageIcon className="w-5 h-5" />
                  Original Artwork
                </h2>
                <div className="rounded-lg overflow-hidden shadow-lg border border-amber-800/10">
                  <img
                    src={originalImage}
                    alt="Original"
                    className="w-full"
                  />
                </div>
              </div>
              <div className="space-y-3">
                <h2 className="font-['Cormorant_Garamond'] text-xl font-semibold text-amber-900 flex items-center gap-2">
                  <ImageIcon className="w-5 h-5" />
                  Transformed Pattern
                </h2>
                <div className="rounded-lg overflow-hidden shadow-lg border border-amber-800/10">
                  <img
                    src={processedImage}
                    alt="Processed"
                    className="w-full"
                  />
                </div>
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => {
                      const link = document.createElement('a');
                      link.download = 'processed-image.png';
                      link.href = processedImage;
                      link.click();
                    }}
                    className="btn-primary flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download Pattern
                  </button>
                  <button
                    onClick={downloadPuzzlePieces}
                    className="btn-secondary flex items-center gap-2"
                  >
                    <Grid className="w-4 h-4" />
                    Download Pieces
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Hidden canvas for processing */}
        <canvas ref={canvasRef} className="hidden" />
        <canvas ref={pieceCanvasRef} className="hidden" />
      </div>
    </div>
  );
}

export default App;